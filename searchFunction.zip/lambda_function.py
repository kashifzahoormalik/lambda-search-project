import json
import requests
from requests.auth import HTTPBasicAuth

# 🔐 Authentication and Endpoint
auth = HTTPBasicAuth("opensearch1", "Opensearch1*")
host = "https://vpc-open-search1-l3oftnpm5vmlv2bqagaf375awa.us-east-1.es.amazonaws.com"

def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
        keyword = body.get("keyword")

        if not keyword:
            return {
                "statusCode": 400,
                "body": json.dumps("Missing 'keyword' in request")
            }

        query = {
            "query": {
                "match": {
                    "content": keyword
                }
            }
        }

        response = requests.get(
            f"{host}/documents/_search",
            auth=auth,
            headers={"Content-Type": "application/json"},
            data=json.dumps(query)
        )

        return {
            "statusCode": response.status_code,
            "body": response.text
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps(f"Error occurred: {str(e)}")
        }

