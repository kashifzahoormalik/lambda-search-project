import json
import requests
from requests.auth import HTTPBasicAuth

def lambda_handler(event, context):
    keyword = event.get('keyword', '')
    if not keyword:
        return {
            'statusCode': 400,
            'body': json.dumps('Missing "keyword" in request')
        }

    opensearch_url = "https://vpc-open-search1-l3oftnpm5vmlv2bqagaf375awa.us-east-1.es.amazonaws.com"
    index = "documents"
    username = "opensearch1"
    password = "Opensearch1*"

    search_url = f"{opensearch_url}/{index}/_search"
    query = {
        "query": {
            "match": {
                "content": keyword
            }
        }
    }

    try:
        response = requests.get(search_url, auth=HTTPBasicAuth(username, password), json=query)
        response.raise_for_status()
        result = response.json()
        return {
            'statusCode': 200,
            'body': json.dumps(result)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Search failed: {str(e)}")
        }

