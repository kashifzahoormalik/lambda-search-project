import boto3
import json
import os
import requests
from requests.auth import HTTPBasicAuth

def get_secret():
    secret_name = "opensearch-master-credentials"
    region_name = "us-east-1"

    client = boto3.client("secretsmanager", region_name=region_name)

    try:
        response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response["SecretString"])
        return secret
    except Exception as e:
        print(f"❌ Failed to retrieve secret: {e}")
        return None

def lambda_handler(event, context):
    print("🚀 Lambda function started.")

    secret = get_secret()
    if secret is None:
        raise Exception("Unable to load OpenSearch credentials from Secrets Manager.")

    username = secret.get("username")
    password = secret.get("password")

    if not username or not password:
        raise Exception("Username or password missing in Secrets Manager secret.")

    print(f"🔐 OpenSearch Username: {username[:3]}***, Password Length: {len(password)}")

    # Get S3 object info from event
    try:
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        file_key = event['Records'][0]['s3']['object']['key']
        print(f"📂 File uploaded to S3 bucket: {bucket_name}, Key: {file_key}")
    except Exception as e:
        raise Exception(f"❌ Failed to parse S3 event: {e}")

    # Download the file content
    try:
        s3_client = boto3.client('s3')
        response = s3_client.get_object(Bucket=bucket_name, Key=file_key)
        file_content = response['Body'].read().decode('utf-8')
        print("✅ File content successfully downloaded.")
    except Exception as e:
        raise Exception(f"❌ Failed to read file from S3: {e}")

    # Index into OpenSearch
    opensearch_url = "https://vpc-open-search1-l3oftnpm5vmlv2bqagaf375awa.us-east-1.es.amazonaws.com/documents/_doc"
    doc = {
        "filename": file_key,
        "content": file_content
    }

    try:
        response = requests.post(
            opensearch_url,
            auth=HTTPBasicAuth(username, password),
            headers={"Content-Type": "application/json"},
            data=json.dumps(doc)
        )
        print(f"📥 OpenSearch response: {response.status_code}, {response.text}")
    except Exception as e:
        raise Exception(f"❌ Failed to index document to OpenSearch: {e}")

    return {
        "statusCode": 200,
        "body": json.dumps("✅ File indexed into OpenSearch successfully!")
    }

