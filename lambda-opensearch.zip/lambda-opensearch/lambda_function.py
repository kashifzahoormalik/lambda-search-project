import boto3
import json
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth

def get_secret():
    secret_name = "opensearch-master-credentials"  # Your actual secret name
    region_name = "us-east-1"
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    
    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(get_secret_value_response['SecretString'])
        return secret
    except Exception as e:
        print(f"❌ Error retrieving secret: {e}")
        return None

def lambda_handler(event, context):
    credentials = get_secret()
    if not credentials:
        print("❌ No credentials found.")
        return {
            "statusCode": 500,
            "body": "No credentials retrieved"
        }

    username = credentials.get("username")
    password = credentials.get("password")
    
    print(f"🔐 OpenSearch Username: {username[:3]}***, Password Length: {len(password)}")

    host = "vpc-open-search1-l3oftnpm5vmlv2bqagaf375awa.us-east-1.es.amazonaws.com"  # Your OpenSearch domain
    region = "us-east-1"
    
    try:
        client = OpenSearch(
            hosts=[{'host': host, 'port': 443}],
            http_auth=(username, password),
            use_ssl=True,
            verify_certs=True,
            connection_class=RequestsHttpConnection
        )
        print("✅ Connected to OpenSearch")

        # Optional: Dummy test doc
        response = client.index(
            index="test-index",
            body={"message": "Hello from Lambda!"},
        )
        print("📦 Document indexed:", response)

        return {
            "statusCode": 200,
            "body": json.dumps("Document indexed successfully.")
        }

    except Exception as e:
        print(f"❌ OpenSearch Error: {e}")
        return {
            "statusCode": 500,
            "body": str(e)
        }

