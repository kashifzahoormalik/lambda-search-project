import json
import os
import boto3
from pdfminer.high_level import extract_text

s3 = boto3.client('s3')
TARGET_BUCKET = os.environ.get('TARGET_BUCKET', 'opensource-kashif')

def lambda_handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        tmp_file = '/tmp/input.pdf'
        s3.download_file(bucket, key, tmp_file)

        text = extract_text(tmp_file)

        output_key = key.rsplit('.', 1)[0] + '.txt'
        s3.put_object(
            Bucket=TARGET_BUCKET,
            Key=output_key,
            Body=text.encode('utf-8')
        )

    return {
        'statusCode': 200,
        'body': json.dumps('PDF converted to text and uploaded!')
    }

